<?php
    session_start();
    require_once '../datebase/Database.php';
    $Db = new Database("projet");

    try {
        $Db->connexion_to_server();
        $Db->create_db();
        $c = $Db->connect_to_db();
    } catch (PDOException $e) {
        die("Database connection failed: " . $e->getMessage());
    }

    if (!isset($_SESSION['agent_logged_in']) || $_SESSION['agent_logged_in'] !== true) {
     
      header("Location: ../main/connect.php"); 
      exit();
  }
    $agentId =   $_SESSION['agentid'] ;

    $stmt = $c->query("SELECT * FROM agent WHERE agentid =  $agentId");
    $agent = $stmt->fetch(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>CodePen - UI #3 - Profile Card</title>
  <meta name="viewport" content="width=device-width, initial-scale=1"><link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.3.1/css/all.css'><link rel="stylesheet" href="./style.css">
  <link rel="stylesheet" href="agent.css" />
  <link rel="stylesheet" href="profilee.css" />
  <link
      href="https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css"
      rel="stylesheet"
    />
</head>
<body>
<div class="card">
  <div class="ds-top"></div>
  <div class="avatar-holder">
   
  <img src="../assets/profile_images/<?php echo $agent['profil']; ?>">
</div>
  <div class="button">
    <a href="#" class="btn"><?php echo  $agent['nom']. ' ' .  $agent['prenom']; ?><i class="fas fa-user-plus"></i></a>
  </div>
  <div class="ds-info">
    <div class="ds pens">
      <h6>ID<i class='bx bxs-id-card'></i></h6>
      <p><?=  $agent['agentid'] ?></p>
    </div>
    <div class="ds projects">
      <h6>Entreprise<i class="fas fa-project-diagram"></i></h6>
      <p>setram</p>
    </div>
    <div class="ds posts">
      <h6>Region<i class='bx bx-map-pin'></i></h6>
      <p>alger</p>
    </div>
  </div>
  <div class="ds-skill">
    <h6>information personelle<i class="fa fa-code" aria-hidden="true"></i></h6>
    <div class="skill html">
      <h6>gmail:</h6>
      <div class="bar bar-html">
        <p><?=  $agent['email'] ?></p>
      </div>
    </div>
  </div>
</div>

<nav>
  <div class="logo">
    <i class="bx bx-menu menu-icon"></i>
    <span class="logo-name">Setram</span>
  </div>
  <div class="sidebar">
    <div class="logo">
      <i class="bx bx-menu menu-icon"></i>
      <span class="logo-name">Setram</span>
    </div>
    <div class="sidebar-content">
      <ul class="lists">
        <li class="list">
          <a href="agent.php" class="nav-link">
            <i class="bx bx-home-alt icon"></i>
            <span class="link">Dashboard</span>
          </a>
        </li>
        <li class="list">
          <a href="utilisateur.php" class="nav-link">
            <i class='bx bx-user icon'></i>
            <span class="link">Users</span>
          </a>
        </li>
        <li class="list">
          <a href="abonement.php" class="nav-link">
            <i class='bx bx-id-card icon'></i>
            <span class="link">Abonnement</span>
          </a>
        </li>
      </ul>
      <div class="bottom-cotent">
        <li class="list">
          <a href="profilee.php" class="nav-link">
            <i class='bx bx-user-circle icon'></i>
            <span class="link">Profile</span>
          </a>
        </li>
        <li class="list">
          <a href="deconnectionn.php" class="nav-link">
            <i class="bx bx-log-out icon"></i>
            <span class="link">deconnection</span>
          </a>
        </li>
      </div>
    </div>
  </div>
</nav>
<section class="overlay"></section>
<script src="agent.js"></script>

<!-- partial -->
  <script  src="profilee.js"></script>

</body>
</html>
