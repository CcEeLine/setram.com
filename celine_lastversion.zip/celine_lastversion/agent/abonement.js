function showStatusOptions(button) {
  var userID = button.getAttribute('data-userid');
  var row = button.closest('tr');

  var dropdown = document.createElement('select');
  dropdown.innerHTML = `
  <option value="">choose:</option>
  <option value="activer">Activer</option>
  <option value="deactiver">Deactiver</option>
  <option value="en_attente">En attente</option>
  `;

  dropdown.classList.add('status-dropdown');

  dropdown.addEventListener('change', function () {
      updateStatus(row, userID, this.value);
      row.removeChild(this);
  });

  row.appendChild(dropdown);
}

function updateStatus(row, userID, newStatus) {
  console.log('Updating status for user ID:', userID, 'to status:', newStatus);

 $.ajax({
  type: 'POST',
  url: 'modifyStatus.php',
  data: { userID: userID, newStatus: newStatus },
  success: function (response) {
      // Handle the response from the server (if needed)
      console.log(response);

      // Reload the page after the status is updated
      location.reload();
  },
  error: function (error) {
      console.error('Error updating status:', error);
  }
});
}
function deleteRow(userID) {
  // Ask for confirmation before deleting the row
  if (confirm("Are you sure you want to delete this row?")) {
    // Perform an AJAX request to delete the row from the server
    $.ajax({
      type: 'POST',
      url: 'delete_abonement.php',
      data: { userID: userID },
      success: function (response) {
        // Handle the response from the server (if needed)
        console.log(response);
  
        // Reload the page after the status is updated
        location.reload();
    },
      error: function() {
        alert('An error occurred during the deletion process.');
      }
    });
  }
}
