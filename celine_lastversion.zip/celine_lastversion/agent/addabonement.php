<?php
    session_start();
    require_once '../datebase/Database.php';

    $Db = new Database("projet");

    try {
        $Db->connexion_to_server();
        $Db->create_db();
        $c = $Db->connect_to_db();
    } catch (PDOException $e) {
        die("Database connection failed: " . $e->getMessage());
    }
    if (!isset($_SESSION['agent_logged_in']) || $_SESSION['agent_logged_in'] !== true) {
     
      header("Location: ../main/connect.php"); 
      exit();
  }


    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add'])) {
        $id = $_POST['id'];
        $date = $_POST['order'];
        $plan = $_POST['plan'];
        $status = 'En attente';


        // Check if clientID exists in the users table
        $check_stmt = $c->prepare("SELECT COUNT(*) FROM users WHERE clientID = ?");
        $check_stmt->execute([$id]);
        $existing_count = $check_stmt->fetchColumn();

        if ($existing_count < 1) {
            $error_message = "Ce client n'existe pas!";
        } else {

            // Insert data into the abonemment table
            $stmt = $c->prepare("INSERT INTO abonemment (clientID, Orderdate, Status, Plan) VALUES (?, ?, ?, ?)");
            $stmt->execute([$id, $date, $status, $plan]);

            // Redirect to the abonement.php page after successful insertion
            header("Location: abonement.php");
            exit();
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add user </title> 
    <link rel="stylesheet" href="addabonement.css">
   </head>

<body>
  <div class="wrapper">
    <h2>ajouter un abonemment</h2>
    <form action="addabonement.php" method="post">
      <div class="input-box">
        <input  for="id" type="number" name="id" placeholder="client ID" required>
        <?php 
          if(isset($error_message)): ?>
            <p style="color: red;"><?php echo $error_message ?? '' ?></small>
           <?php endif; ?>
      </div>
        
      <div class="input-box">
        <input for="date" type="date" name="order" placeholder="Order date" required>
      </div>
      <div class="input-box">
        <input type="radio" id="tram" name="plan" value="tram" required>
        <label for="tram">tram</label>
        <input type="radio" id="tram+metro" name="plan" value="tram+metro" required>
        <label for="tram+metro">tram+metro</label>
        <input type="radio" id="Convention" name="plan" value="Convention" required>
        <label for="Convention">Convention</label>
      </div>
      <div class="input-box button">
        <input type="Submit" name="add" value="Ajouter L'abonemment">
      </div>
    </form>
    <a href="abonement.php" class="btn btn-danger">Revenir a la page precedante</a>
  </div>
</body>
</html>
             








 

