
<?php
session_start();
require_once '../datebase/Database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['userID'])) {
    $Db = new Database("projet");
    try {
        $Db->connexion_to_server();
        $Db->create_db();
        $c = $Db->connect_to_db();

        $userID = $_POST['userID'];

        // Perform the deletion
        $stmt = $c->prepare("DELETE FROM abonemment WHERE ID = :userID");
        $stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
        $stmt->execute();

        // Check if the deletion was successful
        if ($stmt->rowCount() > 0) {
            echo 'success';
        } else {
            echo 'error';
        }
    } catch (PDOException $e) {
        echo 'error';
    }
}
?>
