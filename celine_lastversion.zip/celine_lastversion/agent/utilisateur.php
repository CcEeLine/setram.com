<?php
    session_start();
    require_once '../datebase/Database.php';
    $Db = new Database("projet");
    if (!isset($_SESSION['agent_logged_in']) || $_SESSION['agent_logged_in'] !== true) {
     
      header("Location: ../main/connect.php"); 
      exit();
  }

    try {
        $Db->connexion_to_server();
        $Db->create_db();
        $c = $Db->connect_to_db();
    } catch (PDOException $e) {
        die("Database connection failed: " . $e->getMessage());
    }
   
    $stmt = $c->query("SELECT * FROM users");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
   <title>Dashboard</title>
    <!-- CSS -->
    <link rel="stylesheet" href="utilisateur.css" />
    <!-- Boxicons CSS -->
    <link
      href="https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css"
      rel="stylesheet"
    />
  </head>
  <body>
    <nav>
      <div class="logo">
        <i class="bx bx-menu menu-icon"></i>
        <span class="logo-name">Setram</span>
      </div>
      <div class="sidebar">
        <div class="logo">
          <i class="bx bx-menu menu-icon"></i>
          <span class="logo-name">Setram</span>
        </div>
        <div class="sidebar-content">
          <ul class="lists">
            <li class="list">
              <a href="agent.php" class="nav-link">
                <i class="bx bx-home-alt icon"></i>
                <span class="link">Dashboard</span>
              </a>
            </li>
            <li class="list">
              <a href="utilisateur.php" class="nav-link">
                <i class='bx bx-user icon'></i>
                <span class="link">Users</span>
              </a>
            </li>
            <li class="list">
              <a href="abonement.php" class="nav-link">
                <i class='bx bx-id-card icon'></i>
                <span class="link">Abonnement</span>
              </a>
            </li>
          </ul>
          <div class="bottom-cotent">
            <li class="list">
              <a href="profilee.php" class="nav-link">
                <i class='bx bx-user-circle icon'></i>
                <span class="link">Profile</span>
              </a>
            </li>
            <li class="list">
              <a href="deconnectionn.php" class="nav-link">
                <i class="bx bx-log-out icon"></i>
                <span class="link">deconnection</span>
              </a>
            </li>
          </div>
        </div>
      </div>
    </nav>
   <div>
    </nav>
    <section class="overlay"></section>
        <main class="table" id="customers_table">
            <section class="table__header">
                <h1>table ustilisateurs</h1>
                <div class="input-group">
                    <input type="search" placeholder="Search Data...">
                    <img src="search.png">
                </div>
            </section>
            <section class="table__body">
                <table>
                    <thead>
                        <tr>
                            <th>clientID</th>
                            <th>profile</th>
                            <th>Nom</th>
                            <th>Prenom</th>
                            <th>Date de naissance</th>
                            <th>genre</th>
                            <th>Email</th>
                        </tr>
                    </thead>
                    <tbody class="t_body">
                        
                        <?php foreach ($users as $user) : ?>
                          <tr>
                            <td> <?= $user['clientID'] ?> </td>
                            <td> <img src="../assets/profile_images/<?php echo $user['profile']; ?>"></td>
                            <td><?= $user['Nom'] ?></td>
                            <td><?= $user['Prenom'] ?></td>
                            <td><?= $user['Datedenaissance'] ?></td>
                            <td><?= $user['genre'] ?></td>
                            <td><?= $user['email'] ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </section>
        </main>
        <script src="utilisateur.js"></script>

</body>

</html>
