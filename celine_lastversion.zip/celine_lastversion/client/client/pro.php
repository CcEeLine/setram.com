<?php
    session_start();
    require_once '../../datebase/Database.php';
    $Db = new Database("projet");

    try {
        $Db->connexion_to_server();
        $Db->create_db();
        $c = $Db->connect_to_db();
    } catch (PDOException $e) {
        die("Database connection failed: " . $e->getMessage());
    }

    if (!isset($_SESSION['user_logged_in']) || $_SESSION['user_logged_in'] !== true) {
     
      header("Location: ../../main/connect.php"); 
      exit();
  }
    $clientId =   $_SESSION['clientID'];

    $stmt = $c->query("SELECT * FROM users WHERE clientID =  $clientId");
    $client = $stmt->fetch(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>CodePen - UI #3 - Profile Card</title>
  <meta name="viewport" content="width=device-width, initial-scale=1"><link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.3.1/css/all.css'><link rel="stylesheet" href="./style.css">
  <link rel="stylesheet" href="client.css" />
  <link rel="stylesheet" href="pro.css" />
  <link
      href="https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css"
      rel="stylesheet"
    />
</head>
<body>
<div class="card">
  <div class="ds-top"></div>
  <div class="avatar-holder">
    <img src="../../assets/profile_images/<?php echo $client['profile']; ?>">
</div>
  <div class="button">
    <a href="#" class="btn">client <i class="fas fa-user-plus"></i></a>
  </div>
  <div class="ds-skill">
    <h6>information personelle:</h6>
    <div class="skill html">
      <h6>nom:</h6>
      <div class="bar bar-html">
        <p><?=  $client['Nom'] ?></p>
      </div>
    </div>
    <div class="skill html">
      <h6>prenom:</h6>
      <div class="bar bar-html">
        <p><?=$client['Prenom'] ?></p>
      </div>
    </div>
    <div class="skill html">
      <h6>date de naissance:</h6>
      <div class="bar bar-html">
        <p><?=  $client['Datedenaissance'] ?></p>
      </div>
    </div>
    
  </div>
</div>

<nav>
  <div class="logo">
    <i class="bx bx-menu menu-icon"></i>
    <span class="logo-name">Setram</span>
  </div>
  <div class="sidebar">
    <div class="logo">
      <i class="bx bx-menu menu-icon"></i>
      <span class="logo-name">Setram</span>
    </div>
    <div class="sidebar-content">
      <ul class="lists">
        <li class="list">
          <a href="agent.php" class="nav-link">
            <i class="bx bx-home-alt icon"></i>
            <span class="link">Dashboard</span>
          </a>
        </li>
        <li class="list">
          <a href="utilisateur.php" class="nav-link">
            <i class='bx bx-user icon'></i>
            <span class="link">Users</span>
          </a>
        </li>
        <li class="list">
          <a href="abon.php" class="nav-link">
            <i class='bx bx-id-card icon'></i>
            <span class="link">Abonnement</span>
          </a>
        </li>
        <li class="list">
              <a href="perte.php" class="nav-link">
                <i class='bx bx-id-card icon'></i>
                <span class="link">Perte</span>
              </a>
            </li>
      </ul>
      <div class="bottom-cotent">
        <li class="list">
          <a href="profilee.php" class="nav-link">
            <i class='bx bx-user-circle icon'></i>
            <span class="link">Profile</span>
          </a>
        </li>
        <li class="list">
          <a href="dec.php" class="nav-link">
            <i class="bx bx-log-out icon"></i>
            <span class="link">deconnection</span>
          </a>
        </li>
      </div>
    </div>
  </div>
</nav>
<section class="overlay"></section>
<script src="client.js"></script>

<!-- partial -->
  <script  src="pro.js"></script>

</body>
</html>
