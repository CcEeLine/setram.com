
<?php
  
  session_start();
  require_once '../../datebase/Database.php';
  $Db = new Database("projet");

  // Initialize the success message variable
  $successMessage = '';

  try {
      $Db->connexion_to_server();
      $Db->create_db();
      $c = $Db->connect_to_db();
  } catch (PDOException $e) {
      die("Database connection failed: " . $e->getMessage());
  }

  if (!isset($_SESSION['user_logged_in']) || $_SESSION['user_logged_in'] !== true) {
      header("Location: ../../main/connect.php"); 
      exit();
  }

  $clientId = $_SESSION['clientID'];

  if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['perte'])) {
      $date = $_POST['date'];
      $plan = $_POST['plan'];
      $status = 'En attente';

      try {
          // Insert data into the abonemment table
          $stmt = $c->prepare("INSERT INTO abonemment (clientID, Orderdate, Status, Plan) VALUES (?, ?, ?, ?)");
          $stmt->execute([$clientId, $date, $status, $plan]);

          // Set success message
          $successMessage = 'Demande ajoutée avec succès!';
      } catch (PDOException $e) {
          // Handle database error
          die("Database error: " . $e->getMessage());
      }
  }


?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>inscription </title> 
    <link rel="stylesheet" href="perte.css">
   </head>

<body>
  <div class="wrapper">
    <h2>Demande d'abonemment</h2>
    <?php if (!empty($successMessage)) : ?>
      <p class="success-message" style="color: green;"><?php echo $successMessage; ?></p>
    <?php endif; ?>
    <form action="abon.php" method="post">
      <div class="input-box">
        <input for="date" type="date" name="date" placeholder="Date de perte" required>
      </div>
      <div class="input-box">
        <input type="radio" id="tram" name="plan" value="tram" required>
        <label for="tram">tram</label>
        <input type="radio" id="tram+metro" name="plan" value="tram+metro" required>
        <label for="tram+metro">tram+metro</label>
        <input type="radio" id="Convention" name="plan" value="Convention" required>
        <label for="Convention">Convention</label>
      </div>
      <div class="input-box button">
        <input type="Submit" name="perte" value="envoyer">
      </div>
    </form>
    <a href="client.php" class="btn btn-danger">Revenir a la page precedante</a>
  </div>
</body>
</html>
             








 

