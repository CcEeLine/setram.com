<?php

require_once("Database.php");

class Admin extends Database
{
    public $ID, $Nom, $Email, $Mdp, $type;
    public $connexion;

    public function __construct($ID, $Nom, $Email, $Mdp, $type, $connexion)
    {
        $this->ID = $ID;
        $this->Nom = $Nom;
        $this->Email = $Email;
        $this->Mdp = $Mdp;
        $this->type = $type;
        $this->connexion = $connexion;
    }

    public function createTable()
    {
        $request = "CREATE TABLE IF NOT EXISTS `administrateurs` (
            `ID` int AUTO_INCREMENT PRIMARY KEY,
            `Nom` varchar(255),
            `Email` varchar(255),
            `Password` varchar(255),
            `type` varchar(255)
        )";

        try {
            $stmt = $this->connexion->prepare($request);
            $stmt->execute();
        } catch (PDOException $e) {
            die("Error creating table: " . $e->getMessage());
        }
    }

    public function addAdmin()
    {
        $request = "INSERT INTO `administrateurs` (`Nom`, `Email`, `Password`, `type`) VALUES (:Nom, :Email, :Mdp, :type)";

        try {
            $stmt = $this->connexion->prepare($request);
            $stmt->bindParam(':Nom', $this->Nom);
            $stmt->bindParam(':Email', $this->Email);
            $stmt->bindParam(':Mdp', $this->Mdp);
            $stmt->bindParam(':type', $this->type);
            $stmt->execute();
        } catch (PDOException $e) {
            die("Error adding admin: " . $e->getMessage());
        }
    }
}

// Usage
require_once('/xampp/htdocs/projetwebl3try.php/datebase/admin.php');

$Db = new Database("miniprojet");
$Db->connexion_to_server();
$Db->create_db();

$conn = $Db->connect_to_db();

$Admin = new Admin(null, "lina", "linamouhouche@gmail.com", "lina123", "Admin", $conn);

// Check if the table exists
$tableExists = $conn->query("SHOW TABLES LIKE 'administrateurs'")->rowCount() > 0;

// If the table doesn't exist, create it and add an admin
if (!$tableExists) {
    $Admin->createTable();
    $Admin->addAdmin();
}

?>
