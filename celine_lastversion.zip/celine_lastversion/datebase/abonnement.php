<?php

include_once("Database.php");

class AbonnementActif extends Database
{
    public $NAbonnID, $ClientID, $abonnementActif, $type, $PDFCart;
    public $connexion;


    public function __construct($NAbonnID, $ClientID, $abonnementActif, $type, $PDFCart, $connexion)
    {
        $this->NAbonnID = $NAbonnID;
        $this->ClientID = $ClientID;
        $this->abonnementActif = $abonnementActif;
        $this->type = $type;
        $this->PDFCart = $PDFCart;
        $this->connexion = $connexion;
    }

    public function create_table()
    {
        $request = "CREATE TABLE IF NOT EXISTS AbonnementActif (
            AbonnementID INT AUTO_INCREMENT PRIMARY KEY,
            ClientID INT,
            type VARCHAR(50),
            abonnementActif BOOLEAN,
            PDFCart BLOB,
            FOREIGN KEY (clientID) REFERENCES users(clientID) ON DELETE CASCADE
        )";

        $stmt = $this->connexion->prepare($request);
        $stmt->execute();
    }

    public function addAbonnement()
    {
        $request = "INSERT INTO AbonnementActif (ClientID, type, abonnementActif, PDFCart)
                    VALUES (:ClientID, :type, :abonnementActif, :PDFCart)";

        $stmt = $this->connexion->prepare($request);
        $stmt->bindParam(':ClientID', $this->ClientID, PDO::PARAM_INT);
        $stmt->bindParam(':type', $this->type, PDO::PARAM_STR);
        $stmt->bindParam(':abonnementActif', $this->abonnementActif, PDO::PARAM_BOOL);
        $stmt->bindParam(':PDFCart', $this->PDFCart, PDO::PARAM_LOB);

        $stmt->execute();
    }

    public function updateAbonnement()
    {
        try {
            $PDFCartUpdate = !empty($this->PDFCart) ? ', PDFCart = :updatedPDFCart' : '';
    
            $request = "UPDATE AbonnementActif SET
                        type = :updatedType,
                        abonnementActif = :updatedAbonnementActif
                        $PDFCartUpdate
                        WHERE AbonnementID = :updateNAbonnID";
    
            $stmt = $this->connexion->prepare($request);
            $stmt->bindParam(':updateNAbonnID', $this->NAbonnID, PDO::PARAM_INT);
            $stmt->bindParam(':updatedType', $this->type, PDO::PARAM_STR);
            $stmt->bindParam(':updatedAbonnementActif', $this->abonnementActif, PDO::PARAM_BOOL);
    
            if (!empty($this->PDFCart)) {
                $stmt->bindParam(':updatedPDFCart', $this->PDFCart, PDO::PARAM_LOB);
            }
    
            return $stmt->execute();
        } catch (PDOException $e) {
            die("Error updating abonnement: " . $e->getMessage());
        }
    }
    
    public function getAbonnement()
    {
        $request = "SELECT * FROM AbonnementActif";
        $stmt = $this->connexion->prepare($request);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getAbonnementByClientId($clientID)
    {
        $request = "SELECT * FROM AbonnementActif WHERE ClientID = :clientID";
        $stmt = $this->connexion->prepare($request);
        $stmt->bindParam(':clientID', $clientID, PDO::PARAM_INT);
        $stmt->execute();
    
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    

    public function deleteAboonement()
    {
        $request = "DELETE FROM AbonnementActif WHERE AbonnementID = :deleteNAbonnID";
        $stmt = $this->connexion->prepare($request);
        $stmt->bindParam(':deleteNAbonnID', $this->NAbonnID, PDO::PARAM_INT);
        return $stmt->execute();
    }

    public function getPDFData()
    {
        $request = "SELECT PDFCart FROM AbonnementActif WHERE AbonnementID = :NAbonnID";
        $stmt = $this->connexion->prepare($request);
        $stmt->bindParam(':NAbonnID', $this->NAbonnID, PDO::PARAM_INT);
        $stmt->execute();

        // Fetch the PDF data as binary
        return $stmt->fetch(PDO::FETCH_COLUMN);
    }

    public function getAverageAbonnementByType()
    {
        $request = "SELECT ClientID, type, AVG(abonnementActif) AS averageAbonnement
                    FROM AbonnementActif
                    GROUP BY ClientID, type";

        $stmt = $this->connexion->prepare($request);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    public function getClientInfo($clientID)
{
    $query = "SELECT * FROM users WHERE ClientID = :ClientID";
    $stmt = $this->connexion->prepare($query);
    $stmt->bindParam(':ClientID', $clientID, PDO::PARAM_INT);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result !== false) {
        return $result;
    } else {
        return false;
    }
}

}
