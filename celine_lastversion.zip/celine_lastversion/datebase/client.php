<?php
require_once 'Database.php';

class Users extends Database
{
    public $clientID,$Nom, $Prenom, $Datedenaissance, $genre, $email, $motdepasse,$job;
    public $connexion;
    public $profile;

    public function __construct($clientID, $profile, $Nom, $Prenom, $Datedenaissance, $genre, $email, $motdepasse,$job, $connexion)
    {
        $this->clientID = $clientID;
        $this->profile = $profile;
        $this->Nom = $Nom;
        $this->Prenom = $Prenom;
        $this->Datedenaissance = $Datedenaissance;
        $this->genre = $genre;
        $this->email = $email;
        $this->motdepasse = $motdepasse;
        $this->job = $job;
        $this->connexion = $connexion;
    }

    public function createTable()
    {
        $request = "CREATE TABLE IF NOT EXISTS `users` (
            `clientID` INT AUTO_INCREMENT PRIMARY KEY,
            `profile` BLOB,
            `Nom` VARCHAR(50),
            `Prenom` VARCHAR(50),
            `Datedenaissance` DATE,
            `genre` VARCHAR(50),
            `email` VARCHAR(50),
            `motdepasse` VARCHAR(50),
            `job` VARCHAR(50)
        )";

        $x = $this->connexion->prepare($request);
        $e = $x->execute();
    }

    public function addUser()
    {
        $request = "INSERT INTO `users` (`profile`, `Nom`, `Prenom`, `Datedenaissance`, `genre`, `email`, `motdepasse`,`job`) VALUES (
            :profile, :Nom, :Prenom, :Datedenaissance, :genre, :email, :motdepasse, :job
        )";

        $x = $this->connexion->prepare($request);
        $x->bindParam(':profile', $this->profile, PDO::PARAM_LOB);
        $x->bindParam(':Nom', $this->Nom, PDO::PARAM_STR);
        $x->bindParam(':Prenom', $this->Prenom, PDO::PARAM_STR);
        $x->bindParam(':Datedenaissance', $this->Datedenaissance, PDO::PARAM_STR);
        $x->bindParam(':genre', $this->genre, PDO::PARAM_STR);
        $x->bindParam(':email', $this->email, PDO::PARAM_STR);
        $x->bindParam(':motdepasse', $this->motdepasse, PDO::PARAM_STR);
        $x->bindParam(':job', $this->job, PDO::PARAM_STR);
        $x->execute();
    }

    public function updateUser()
    {
        $request = "UPDATE `users` SET
            `Nom` = :Nom,
            `profile` = :profile,
            `Prenom` = :Prenom,
            `Datedenaissance` = :Datedenaissance,
            `genre` = :genre,
            `email` = :email,
            `motdepasse` = :motdepasse,
            WHERE `clientID` = :clientID";

        $params = [
            ':Nom' => $this->Nom,
            ':profile' => $this->profile,
            ':Prenom' => $this->Prenom,
            ':Datedenaissance' => $this->Datedenaissance,
            ':genre' => $this->genre,
            ':email' => $this->email,
            ':motdepasse' => $this->motdepasse,
            ':clientID' => $this->clientID
        ];

        $x = $this->connexion->prepare($request);
        $e = $x->execute($params);
    }

    public function deleteUser()
    {
        $request = "DELETE FROM `users` WHERE `clientID` = :clientID";

        $x = $this->connexion->prepare($request);
        $params = [':clientID' => $this->clientID];
        $e = $x->execute($params);
    }

    public function displayUsers()
    {
        $tableName = 'users';

        $tableCheck = "SHOW TABLES LIKE '{$tableName}'";
        $tableExists = $this->connexion->query($tableCheck)->rowCount() > 0;

        if (!$tableExists) {
            echo "Table '{$tableName}' does not exist.";
            return;
        }

        $result = $this->connexion->query("SELECT * FROM users");
        echo "<h2>Users</h2>";
        echo "<table><tr><th>clientID</th><th>Nom</th><th>Prenom</th><th>Datedenaissance</th><th>Genre</th><th>Email</th><th>Motdepasse</th><th>job</th></tr>";

        while ($row = $result->fetch()) {
            echo "<tr><td>{$row['clientID']}</td><td>{$row['Nom']}</td><td>{$row['Prenom']}</td><td>{$row['Datedenaissance']}</td><td>{$row['genre']}</td><td>{$row['email']}</td><td>{$row['motdepasse']}</td><td>{$row['job']}</td></tr>";
        }

        echo "</table>";
    }

    public function getUsers()
    {
        $request = "SELECT * FROM `users`";

        try {
            $stmt = $this->connexion->prepare($request);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return false;
        }
    }

    public function resetPasswordRequest($email)
    {
        $request = "UPDATE `users` SET `email` = :email WHERE `email` = :email";
        $stmt = $this->connexion->prepare($request);
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->execute();

        return true;
    }
    

    public function resetPassword($email, $newPassword)
    {
        $request = "UPDATE `users` SET `motdepasse` = :newPassword WHERE `email` = :email";
        $stmt = $this->connexion->prepare($request);
        $stmt->bindParam(':newPassword', $newPassword, PDO::PARAM_STR);
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->execute();

        return true;
    }
    public function getuserData($ClientID)
    {

        $request = "SELECT * FROM `users` WHERE `clientID` = :clientID";
        $stmt = $this->connexion->prepare($request);
        $stmt->bindParam(':clientID', $ClientID, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);

    }
    

}

?>
