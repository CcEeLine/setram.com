<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>setram</title>
    <link rel="stylesheet" href="index.css">
    
</head>
<body>
    <div class="banner">
        <img src="cover.jpg" width="1310"/>
    </div>
    <div>
        <button type="button"><a href="connect.php">log in</a></button>
        <button type="button"><a  href="../admin/connect/connect.php">log in as an admin</a></button>

</body>
</html>