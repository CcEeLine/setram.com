<?php
session_start();
require_once '../datebase/Database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit'])) {
    $email = $_POST['email'];
    $password = $_POST['motdepasse'];

    $Db = new Database("projet");

    try {
        $Db->connexion_to_server();
        $Db->create_db();
        $c = $Db->connect_to_db();
    } catch (PDOException $e) {
        die("Database connection failed: " . $e->getMessage());
    }

    // Check if the user is an agent
    $stmtAgent = $c->prepare("SELECT agentid, email, password FROM agent WHERE email = ?");
    $stmtAgent->execute([$email]);
    $agent = $stmtAgent->fetch(PDO::FETCH_ASSOC);

    // Check if the user is a regular user
    $stmtUser = $c->prepare("SELECT clientID, email, motdepasse FROM users WHERE email = ?");
    $stmtUser->execute([$email]);
    $user = $stmtUser->fetch(PDO::FETCH_ASSOC);

    if ($agent && $password == $agent['password']) {
        $_SESSION['agentid'] = $agent['agentid'];
        $_SESSION['email'] = $agent['email'];
		$_SESSION['agent_logged_in'] = true;

        // Redirect to the agent dashboard
        header("Location: ../agent/agent.php");
        exit();
    } elseif ($user && $password == $user['motdepasse']) {
        $_SESSION['clientID'] = $user['clientID'];
        $_SESSION['email'] = $user['email'];
		$_SESSION['user_logged_in'] = true;

        // Redirect to the user dashboard
        header("Location: ../client/client/client.php");
        exit();
    } else {
        $error_message = "Email or password is incorrect!";
    }
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>connecter</title>
	<link rel="stylesheet" type="text/css" href="connect.css">
	<link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/a81368914c.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
	<img class="wave" src="../admin/img/wave.png">
	<div class="container">
		<div class="img">
			<img src="../admin/img/1.jpg">
		</div>
		<div class="login-content">
			<form action="connect.php" method="post">
				<img src="../admin/img/logo.png">
				<h2 class="title">Welcome to Setram space</h2>
           		<div class="input-div one">
           		   <div class="i">
           		   		<i class="fas fa-user"></i>
           		   </div>
           		   <div class="div">
           		   		<h5>Email</h5>
           		   		<input type="text" name="email"  class="input">
           		   </div>
           		</div>
           		<div class="input-div pass">
           		   <div class="i"> 
           		    	<i class="fas fa-lock"></i>
           		   </div>
           		   <div class="div">
           		    	<h5>mot de passe</h5>
           		    	<input type="password" name="motdepasse" class="input">
            	   </div>
            	</div>
            	<input type="submit" class="btn"  name="submit" value="connecter">
				<?php if (isset($error_message)) : ?>
					<p style="color: red;"><?php echo $error_message ?? '' ?></small>
              <?php endif; ?>
				<div class="signup-link">
            		<p>Vous n'avez pas de compte ? <a href="inscription.php">S'inscrire</a></p>
        		</div>
				<div class="signup-link">
					<p>Vous avez oblier le mot de passe ? <a href="pwd.php">Mot de passe oublié</a></p>
				</div>
            </form>
        </div>
    </div>
    <script type="text/javascript" src="connect.js"></script>
  </body>
</html>