<?php
session_start();
require_once '../datebase/Database.php';

$Db = new Database("projet");

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajouter'])) {
    $uploadDir = '../assets/profile_images/';
    $uploadFile = $uploadDir . basename($_FILES['profile']['name']);

    // Move the uploaded file to the specified directory
    if (move_uploaded_file($_FILES['profile']['tmp_name'], $uploadFile)) {
        // Extract only the file name without the path
        $profil = basename($_FILES['profile']['name']);
    } else {
        // Handle file upload error
        die("File upload failed!");
    }

    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $dateNaissance = $_POST['date'];
    $genre = $_POST['genre'];
    $email = $_POST['email'];
    $password = $_POST['motdepasse']; 

    // Check the selected role
    $role = $_POST['role'];

    try {
        $Db->connexion_to_server();
        $Db->create_db();
        $c = $Db->connect_to_db();

        if ($role === 'agent') {
            // Insert agent data into the database
            $stmt = $c->prepare("INSERT INTO agent (profil, nom, prenom, datedenaissance, genre, email, password) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$profil, $nom, $prenom, $dateNaissance, $genre, $email, $password]);
        } elseif ($role === 'client') {
            // Insert client data into the database
            $stmt = $c->prepare("INSERT INTO users (profile, Nom, Prenom, Datedenaissance, genre, email, motdepasse) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$profil, $nom, $prenom, $dateNaissance, $genre, $email, $password]);
        } else {
            // Handle unknown role
            die("Invalid role");
        }

        // Redirect to a success page or login page after successful signup
        header("Location: connect.php");
        exit();
    } catch (PDOException $e) {
        die("Database error: " . $e->getMessage());
    }
}
?>

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>inscription </title> 
    <link rel="stylesheet" href="pwd.css">
   </head>

<body>
  <div class="wrapper">
    <h2>S'insecrire</h2>
    <form action="inscription.php" method="post" enctype="multipart/form-data">
    <div>
        <p>Image de profil </p>
        <input type="file" id="profile" name="profile"  placeholder="Image de profil" required>
      </div>
      <div class="input-box">
        <input for="nom"  type="text" name="nom" placeholder="Nom" required>
      </div>
      <div class="input-box">
        <input for="prenom"  type="text" name="prenom" placeholder="Prenom" required>
      </div>
      <div class="input-box">
        <input for="date" type="date" name="date" placeholder="Date de naissance" required>
      </div>
      <div class="input-box">
        <input type="radio" id="homme" name="genre" value="homme" required>
        <label for="homme">homme</label>
        <input type="radio" id="femme" name="genre" value="femme" required>
        <label for="femme">femme</label>
      </div>

      <div class="input-box">
    <input type="radio" id="agent" name="role" value="agent" required>
    <label for="agent">agent</label>
    <input type="radio" id="client" name="role" value="client" required>
    <label for="client">client</label>
</div>

      <div class="input-box">
        <input for="email" type="email" name="email" placeholder="Email" required>
      </div>
      <div class="input-box">
        <input for="password" type="password" name="motdepasse" placeholder="mot de passe" required>
      </div>
      <div class="input-box button">
        <input type="Submit" name="ajouter" value="S'insecrire">
      </div>
    </form>
    <a href="connect.php" class="btn btn-danger">Revenir a la page precedante</a>
  </div>
</body>
</html>
             








 

