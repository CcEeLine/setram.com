<?php
session_start();
require_once '../datebase/Database.php';
$Db = new Database("projet");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the form is submitted
    if (isset($_POST['nvmotdepass'])) {
        // Validate and sanitize the input
        $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
        $newPassword = $_POST['motdepasse'];
        $confirmPassword = $_POST['motdepasse_confirm'];
        

        if (!$email || $newPassword !== $confirmPassword) {
            // Handle validation errors
            echo 'Invalid email or passwords do not match.';
            exit();
        }

        // Update the password in the users table
        try {
            $c = $Db->connect_to_db();

            $stmt = $c->prepare("UPDATE users SET motdepasse = :newPassword WHERE email = :email");
            $stmt->bindParam(':newPassword', $newPassword, PDO::PARAM_STR);
            $stmt->bindParam(':email', $email, PDO::PARAM_STR);
            $stmt->execute();

            // Password updated successfully
            $successMessage = 'Reinsialiser avec succès!';
        } catch (PDOException $e) {
            // Handle database error
            echo 'Error updating password: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add user </title> 
    <link rel="stylesheet" href="pwd.css">
   </head>

<body>
  <div class="wrapper">
    <h2>Reinsialiser mot de passe</h2>
    <?php if (!empty($successMessage)) : ?>
      <p class="success-message" style="color: green;"><?php echo $successMessage; ?></p>
    <?php endif; ?>
    <form action="pwd.php" method="post">
      <div class="input-box">
        <input for="email" type="email" name="email" placeholder="Email" required>
      </div>
      <div class="input-box">
        <input for="password" type="password" name="motdepasse" placeholder="nouveau mot de passe" required>
      </div>
      <div class="input-box">
        <input for="password" type="password" name="motdepasse_confirm" placeholder="confirmer mot de passe" required> 
      </div>
      <div class="input-box button">
        <input type="Submit" name="nvmotdepass" value="Reinsialiser mot de passe">
      </div>
    </form>
    <a href="connect.php" class="btn btn-danger">Revenir a la page precedante</a>
  </div>
</body>
</html>
             








 

