<?php
    session_start();
    require_once '../../datebase/Database.php';
    $Db = new Database("projet");

    try {
        $Db->connexion_to_server();
        $Db->create_db();
        $c = $Db->connect_to_db();
    } catch (PDOException $e) {
        die("Database connection failed: " . $e->getMessage());
    }
    if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
      // Admin is not logged in, redirect to the login page or show an error message
      header("Location: ../connect/connect.php"); // Change 'login.php' to your actual login page
      exit();
  }
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajouter'])) {
        $id = $_POST['id'];
        $nom = $_POST['nom'];
        $prenom = $_POST['prenom'];
        $date = $_POST['date'];
        $genre = $_POST['genre'];
        $email = $_POST['email'];
        $motdepasse = $_POST['motdepasse'];
    
        $check_stmt = $c->prepare("SELECT COUNT(*) FROM users WHERE clientID = ?");
        $check_stmt->execute([$id]);
        $existing_count = $check_stmt->fetchColumn();
    
        if ($existing_count > 0) {
            $error_message = "Cette identifiant existe déjà!";
        } else {
            
            $stmt = $c->prepare("INSERT INTO users (clientID, Nom, Prenom, Datedenaissance, genre, email, motdepasse) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$id, $nom, $prenom, $date, $genre, $email, $motdepasse ]);
    
            header("Location: users.php");
            exit();
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add user </title> 
    <link rel="stylesheet" href="add.css">
   </head>

<body>
  <div class="wrapper">
    <h2>Add user</h2>
    <form action="ajouter.php" method="post">
      <div class="input-box">
        <input  for="id" type="number" name="id" placeholder="client ID" required>
        <?php 
          if(isset($error_message)): ?>
            <p style="color: red;"><?php echo $error_message ?? '' ?></small>
           <?php endif; ?>
      </div>
      <div class="input-box">
        <input for="nom"  type="text" name="nom" placeholder="Nom" required>
      </div>
      <div class="input-box">
        <input for="prenom"  type="text" name="prenom" placeholder="Prenom" required>
      </div>
      <div class="input-box">
        <input for="date" type="date" name="date" placeholder="Date de naissance" required>
      </div>
      <div class="input-box">
        <input type="radio" id="homme" name="genre" value="homme" required>
        <label for="homme">homme</label>
        <input type="radio" id="femme" name="genre" value="femme" required>
        <label for="femme">femme</label>
      </div>
      <div class="input-box">
        <input for="email" type="email" name="email" placeholder="Email" required>
      </div>
      <div class="input-box">
        <input for="password" type="password" name="motdepasse" placeholder="mot de passe" required> <!--toujour cree 0000--->
      </div>
      <div class="input-box button">
        <input type="Submit" name="ajouter" value="Ajouter user">
      </div>
    </form>
    <a href="users.php" class="btn btn-danger">Revenir a la page precedante</a>
  </div>
</body>
</html>
             








 

