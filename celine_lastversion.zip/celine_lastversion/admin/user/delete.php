<?php
session_start();
require_once '../../datebase/Database.php';

$Db = new Database("projet");

try {
    $Db->connexion_to_server();
    $Db->create_db();
    $c = $Db->connect_to_db();
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $id_to_delete = $_GET['id'];

 
    $stmt = $c->prepare("DELETE FROM users WHERE clientID = ?");
    $stmt->execute([$id_to_delete]);


    header("Location: users.php");
    exit();
} else {
  
    echo "Invalid request.";
}
?>
