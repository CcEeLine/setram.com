<?php
    session_start();
    require_once '../../datebase/Database.php';
    $Db = new Database("projet");

    try {
        $Db->connexion_to_server();
        $Db->create_db();
        $c = $Db->connect_to_db();
    } catch (PDOException $e) {
        die("Database connection failed: " . $e->getMessage());
    }
    if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
      // Admin is not logged in, redirect to the login page or show an error message
      header("Location: ../connect/connect.php"); // Change 'login.php' to your actual login page
      exit();
  }
// Query to get the count of users
$stmt = $c->query("SELECT COUNT(*) as userCount FROM users");
$userCount = $stmt->fetchColumn();

// Query to get the count of subscribers
$stmt2 = $c->query("SELECT COUNT(*) as subCount FROM abonemment");
$subCount = $stmt2->fetchColumn();

// Query to get the count of active subscribers
$stmt3 = $c->query("SELECT COUNT(*) as Active_subCount FROM abonemment where Status = 'activer' ");
$Active_subCount = $stmt3->fetchColumn();

// Query to get the count of tramway subscribers
$stmt4 = $c->query("SELECT COUNT(*) as Tram_subCount FROM abonemment where Plan = 'tram' or Plan = 'Tram' ");
$Tram_subCount = $stmt4->fetchColumn();

// Query to get the count of tramway + metro subscribers
$stmt5 = $c->query("SELECT COUNT(*) as Trametro_subCount FROM abonemment WHERE Plan ='tram+metro' ");
$Trametro_subCount = $stmt5->fetchColumn();

// Query to get the count of convention subscribers
$stmt6 = $c->query("SELECT COUNT(*) as conv_subCount FROM abonemment where Plan = 'convention' or Plan = 'Convention' ");
$conv_subCount = $stmt6->fetchColumn();
  
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
   <title>Dashboard</title>
    <!-- CSS -->
    <link rel="stylesheet" href="../subscribtion/subs.css" />
    <!-- Boxicons CSS -->
    <link
      href="https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css"
      rel="stylesheet"
    />
  </head>
  <body>
    <nav>
      <div class="logo">
        <i class="bx bx-menu menu-icon"></i>
        <span class="logo-name">Setram</span>
      </div>
      <div class="sidebar">
        <div class="logo">
          <i class="bx bx-menu menu-icon"></i>
          <span class="logo-name">Setram</span>
        </div>
        <div class="sidebar-content">
          <ul class="lists">
            <li class="list">
              <a href="../index.php" class="nav-link">
                <i class="bx bx-home-alt icon"></i>
                <span class="link">Dashboard</span>
              </a>
            </li>
            <li class="list">
              <a href="statistics.php" class="nav-link">
                <i class='bx bx-bar-chart-alt-2 icon'></i>
                <span class="link">Statistique</span>
              </a>
            </li>
            <li class="list">
              <a href="../user/users.php" class="nav-link">
                <i class='bx bx-user icon'></i>
                <span class="link">Users</span>
              </a>
            </li>
            <li class="list">
              <a href="../agent/agents.php" class="nav-link">
                <i class='bx bx-user-pin icon'></i>
                <span class="link">Agent</span>
              </a>
            </li>
            <li class="list">
              <a href="../subscribtion/subscribtion.php" class="nav-link">
                <i class='bx bx-id-card icon'></i>
                <span class="link">Abonnement</span>
              </a>
            </li>
            <li class="list">
                <a href="../declaration/declaration.php" class="nav-link">
                  <i class='bx bxs-bell-ring'></i>
                  <span class="link">Declaration de parte</span>
                </a>
            </li>
          </ul>
          <div class="bottom-cotent">
            <li class="list">
              <a href="../profile/index.php" class="nav-link">
                <i class='bx bx-user-circle icon'></i>
                <span class="link">Profile</span>
              </a>
            </li>
            <li class="list">
              <a href="../deconnection.php" class="nav-link">
                <i class="bx bx-log-out icon"></i>
                <span class="link">deconnection</span>
              </a>
            </li>
          </div>
        </div>
      </div>
    </nav>
   <div>
    </nav>
    <section class="overlay"></section>
    <main class="table" id="customers_table">
        <section class="table__header">
            <h1>Table Des Statistique</h1>
        </section>
        <section class="table__body">
            <table>
                <tbody>
                        <tr>
                          <th>Nombre d'inscrit</th>
                          <td><?php echo $userCount; ?></td></th>
                        </tr>
                        <tr>
                          <th>Nombre d'abonné </th>
                          <td><?php echo $subCount; ?></td></th>
                        </tr><tr>
                          <th>Nombre d'abonné actif</th>
                          <td><?php echo $Active_subCount; ?></td></th>
                        </tr><tr>
                          <th>Abonné Tramway </th>
                          <td><?php echo $Tram_subCount; ?></td></th>
                        </tr><tr>
                          <th>Abonné Tramway + Metro:</th>
                          <td><?php echo $Trametro_subCount; ?></td></th>
                        </tr><tr>
                          <th>Abonné Convention :</th>
                          <td><?php echo $conv_subCount; ?></td></th>
                        </tr>
                    </tbody>
            </table>
        </section>
    </main>
    <section class="overlay"></section>
    <script src="../index.js"></script>
</body>
</html>
