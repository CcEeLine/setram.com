<?php
session_start();
require_once '../../datebase/Database.php';

if (isset($_POST['userID']) && isset($_POST['currentStatus'])) {
    $userID = $_POST['userID'];
    $currentStatus = $_POST['currentStatus'];
    $newStatus = 'traiter'; // Set the new status here

    // Update the status in the database
    $stmt = $c->prepare("UPDATE perte SET Status = :newStatus WHERE ID = :userID AND Status = :currentStatus");
    $stmt->bindParam(':newStatus', $newStatus, PDO::PARAM_STR);
    $stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
    $stmt->bindParam(':currentStatus', $currentStatus, PDO::PARAM_STR);
    $stmt->execute();

    // Return the new status as a response
    echo json_encode(['newStatus' => $newStatus]);
} else {
    echo json_encode(['error' => 'Invalid request']);
}
?>
