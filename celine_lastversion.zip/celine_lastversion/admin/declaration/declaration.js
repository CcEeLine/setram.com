const navBar = document.querySelector("nav"),
       menuBtns = document.querySelectorAll(".menu-icon"),
       overlay = document.querySelector(".overlay");

     menuBtns.forEach((menuBtn) => {
       menuBtn.addEventListener("click", () => {
         navBar.classList.toggle("open");
       });
     });

     overlay.addEventListener("click", () => {
       navBar.classList.remove("open");
     });

    
// declaration.js

document.addEventListener("DOMContentLoaded", function () {
  const statusElements = document.querySelectorAll(".status");

  statusElements.forEach((statusElement) => {
      statusElement.addEventListener("click", function () {
          if (this.classList.contains("cancelled")) {
              // Change the status in the front end
              this.textContent = "traiter";
              this.classList.remove("cancelled");
              this.classList.add("delivered");

              // Get the userID and currentStatus from data attributes
              const userID = this.dataset.userid;
              const currentStatus = this.dataset.currentstatus;

              // Make an AJAX request to update the status in the database
              updateStatusInDatabase(userID, currentStatus);
          }
      });
  });

  function updateStatusInDatabase(userID, currentStatus) {
      // Create an XMLHttpRequest object
      const xhr = new XMLHttpRequest();

      // Configure it to make a POST request to your PHP script
      xhr.open("POST", "update_state.php", true);
      xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

      // Define the data to be sent in the request
      const data = `userID=${userID}&currentStatus=${currentStatus}`;

      // Set up a callback function to handle the response from the server
      xhr.onreadystatechange = function () {
          if (xhr.readyState === 4 && xhr.status === 200) {
              const response = JSON.parse(xhr.responseText);
              // Handle the response, e.g., update the UI based on the new status
              console.log(response);
          }
      };

      // Send the request with the data
      xhr.send(data);
  }
});


  
// Sorting | Ordering data of HTML table

table_headings.forEach((head, i) => {
    let sort_asc = true;
    head.onclick = () => {
        table_headings.forEach(head => head.classList.remove('active'));
        head.classList.add('active');

        document.querySelectorAll('td').forEach(td => td.classList.remove('active'));
        table_rows.forEach(row => {
            row.querySelectorAll('td')[i].classList.add('active');
        })

        head.classList.toggle('asc', sort_asc);
        sort_asc = head.classList.contains('asc') ? false : true;

        sortTable(i, sort_asc);
    }
})


function sortTable(column, sort_asc) {
    [...table_rows].sort((a, b) => {
        let first_row = a.querySelectorAll('td')[column].textContent.toLowerCase(),
            second_row = b.querySelectorAll('td')[column].textContent.toLowerCase();

        return sort_asc ? (first_row < second_row ? 1 : -1) : (first_row < second_row ? -1 : 1);
    })
        .map(sorted_row => document.querySelector('tbody').appendChild(sorted_row));
}


