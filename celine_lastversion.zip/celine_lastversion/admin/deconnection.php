<?php
session_start();

// Détruire la session
session_destroy();

// Rediriger vers la page de connexion (ou une autre page de votre choix)
header("Location: ./connect/connect.php"); // Changez 'login.php' en votre page de connexion réelle
exit();
?>
