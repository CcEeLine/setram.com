<?php
    session_start();
    require_once '../.././datebase/Database.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>Animated Login Form</title>
	<link rel="stylesheet" type="text/css" href="connectadmin.css">
	<link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/a81368914c.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
	<img class="wave" src="../img/wave.png">
	<div class="container">
		<div class="img">
			<img src="../img/1.jpg">
		</div>
		<div class="login-content">
			<form action="connect.php" method="post">
				<img src="../img/logo.png">
				<h2 class="title">Welcome to Setram Admin space</h2>
           		<div class="input-div one">
           		   <div class="i">
           		   		<i class="fas fa-user"></i>
           		   </div>
           		   <div class="div">
           		   		<h5>Email</h5>
           		   		<input type="text" name="email"  class="input">
           		   </div>
           		</div>
           		<div class="input-div pass">
           		   <div class="i"> 
           		    	<i class="fas fa-lock"></i>
           		   </div>
           		   <div class="div">
           		    	<h5>mot de passe</h5>
           		    	<input type="password" name="motdepasse" class="input">
            	   </div>
            	</div>
            	<input type="submit" class="btn"  name="submit" value="connecter">
            </form>
        </div>
    </div>
    <script type="text/javascript" src="connect.js"></script>
    <?php
         $Db = new Database("projet");

         try {
             $Db->connexion_to_server();
             $Db->create_db();
             $c = $Db->connect_to_db();
         } catch (PDOException $e) {
             die("Database connection failed: " . $e->getMessage());
         }
     
         if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit'])) {
             $stmt3 = $c->prepare("SELECT ID, Nom, Email, Password FROM administrateurs WHERE Email = ?");
             $stmt3->execute([$_POST['email']]);
             $administrateurs = $stmt3->fetch(PDO::FETCH_ASSOC);
     
             if ($administrateurs && $_POST['motdepasse'] === $administrateurs['Password']) {
                 $_SESSION['ID'] = $administrateurs['ID'];
                 $_SESSION['Nom'] = $administrateurs['Nom'];
                 $_SESSION['Email'] = $administrateurs['Email'];
				 $_SESSION['admin_logged_in'] = true;
     
                 header("Location: ../index.php");
             } else {
                 echo "Adresse e-mail ou mot de passe incorrect";
             }
         }
    ?>
  </body>
</html>