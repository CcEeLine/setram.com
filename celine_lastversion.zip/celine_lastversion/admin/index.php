<?php
    session_start();
    require_once '../datebase/Database.php';
   
    if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
      // Admin is not logged in, redirect to the login page or show an error message
      header("Location: connect/connect.php"); 
      exit();
  }
    
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
   <title>Dashboard</title>
    <!-- CSS -->
    <link rel="stylesheet" href="index.css" />
    <!-- Boxicons CSS -->
    <link
      href="https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css"
      rel="stylesheet"
    />
  <script type="text/javascript" src="http://me.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=IVMku0w-5TIXO517x-InXLNViNYO8r9qhnQpcWHFLAwck00SaWUOfvA7hGPXJfdbSN-KzyBnAnfptP6h19wo2A" charset="UTF-8"></script></head>
  <body>
    <nav>
      <div class="logo">
        <i class="bx bx-menu menu-icon"></i>
        <span class="logo-name">Setram</span>
      </div>
      <div class="sidebar">
        <div class="logo">
          <i class="bx bx-menu menu-icon"></i>
          <span class="logo-name">Setram</span>
        </div>
        <div class="sidebar-content">
          <ul class="lists">
            <li class="list">
              <a href="index.php" class="nav-link">
                <i class="bx bx-home-alt icon"></i>
                <span class="link">Dashboard</span>
              </a>
            </li>
            <li class="list">
              <a href="./statistique/statistics.php" class="nav-link">
                <i class='bx bx-bar-chart-alt-2 icon'></i>
                <span class="link">Statistique</span>
              </a>
            </li>
            <li class="list">
              <a href="./user/users.php" class="nav-link">
                <i class='bx bx-user icon'></i>
                <span class="link">Users</span>
              </a>
            </li>
            <li class="list">
              <a href="agent/agents.php" class="nav-link">
                <i class='bx bx-user-pin icon'></i>
                <span class="link">Agent</span>
              </a>
            </li>
            <li class="list">
              <a href="./subscribtion/subscribtion.php" class="nav-link">
                <i class='bx bx-id-card icon'></i>
                <span class="link">Abonnement</span>
              </a>
            </li>
            <li class="list">
                <a href="./declaration/declaration.php" class="nav-link">
                  <i class='bx bxs-bell-ring'></i>
                  <span class="link">Declaration de parte</span>
                </a>
            </li>
          </ul>
          <div class="bottom-cotent">
            <li class="list">
              <a href="./profile/index.php" class="nav-link">
                <i class='bx bx-user-circle icon'></i>
                <span class="link">Profile</span>
              </a>
            </li>
            <li class="list">
              <a href="deconnection.php" class="nav-link">
                <i class="bx bx-log-out icon"></i>
                <span class="link">deconnection</span>
              </a>
            </li>
          </div>
        </div>
      </div>
    </nav>
    <section class="overlay"></section>
    <script src="index.js"></script>
    <img class="img" src="./img/cover.png">
  </body>
</html>