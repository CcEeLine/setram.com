function showStatusOptions(button) {
    var userID = button.getAttribute('data-userid');
    var row = button.closest('tr');

    var dropdown = document.createElement('select');
    dropdown.innerHTML = `
        <option value="">choose:</option>
        <option value="activer">Activer</option>
        <option value="deactiver">Deactiver</option>
        <option value="en_attente">En attente</option>
    `;

    dropdown.classList.add('status-dropdown');

    dropdown.addEventListener('change', function () {
        updateStatus(row, userID, this.value);
        row.removeChild(this);
    });

    row.appendChild(dropdown);
}

function updateStatus(row, userID, newStatus) {
    console.log('Updating status for user ID:', userID, 'to status:', newStatus);

   $.ajax({
    type: 'POST',
    url: 'modifyStatus.php',
    data: { userID: userID, newStatus: newStatus },
    success: function (response) {
        // Handle the response from the server (if needed)
        console.log(response);

        // Reload the page after the status is updated
        location.reload();
    },
    error: function (error) {
        console.error('Error updating status:', error);
    }
});
}
