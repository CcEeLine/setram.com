<?php
session_start();
require_once '../../datebase/Database.php';

try {
    $Db = new Database("projet");
    $Db->connexion_to_server();
    $Db->create_db();
    $c = $Db->connect_to_db();
} catch (PDOException $e) {
    // Log error message
    error_log('Database connection failed: ' . $e->getMessage());

    // Handle database connection error (if needed)
    echo 'Error connecting to the database';
    exit();
}

// Check if the required data is received
if (isset($_POST['userID'], $_POST['newStatus'])) {
    $userID = $_POST['userID'];
    $newStatus = $_POST['newStatus'];

    try {
        $stmt = $c->prepare("UPDATE abonemment SET Status = :newStatus WHERE ID = :userID");
        $stmt->bindParam(':newStatus', $newStatus, PDO::PARAM_STR);
        $stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
        $stmt->execute();

        error_log('Status updated successfully');
        echo 'Status updated successfully';
    } catch (PDOException $e) {
        error_log('Error updating status: ' . $e->getMessage());
        echo 'Error updating status: ' . $e->getMessage();
    }
} else {
    error_log('Invalid or missing POST data');
    echo 'Invalid or missing POST data';
}
?>
