<?php
    session_start();
    require_once '../../datebase/Database.php';
    $Db = new Database("projet");

    try {
        $Db->connexion_to_server();
        $Db->create_db();
        $c = $Db->connect_to_db();
    } catch (PDOException $e) {
        die("Database connection failed: " . $e->getMessage());
    }
    if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
      // Admin is not logged in, redirect to the login page or show an error message
      header("Location: ../connect/connect.php"); 
      exit();
  }
    $stmt = $c->query("SELECT * FROM abonemment");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

    
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

   <title>Dashboard</title>
    <!-- CSS -->
    <link rel="stylesheet" href="subs.css" />
    <!-- Boxicons CSS -->
    <link
      href="https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css"
      rel="stylesheet"
    />
  </head>
  <body>
    <nav>
      <div class="logo">
        <i class="bx bx-menu menu-icon"></i>
        <span class="logo-name">Setram</span>
      </div>
      <div class="sidebar">
        <div class="logo">
          <i class="bx bx-menu menu-icon"></i>
          <span class="logo-name">Setram</span>
        </div>
        <div class="sidebar-content">
          <ul class="lists">
            <li class="list">
              <a href="../index.php" class="nav-link">
                <i class="bx bx-home-alt icon"></i>
                <span class="link">Dashboard</span>
              </a>
            </li>
            <li class="list">
              <a href="../statistique/statistics.php" class="nav-link">
                <i class='bx bx-bar-chart-alt-2 icon'></i>
                <span class="link">Statistique</span>
              </a>
            </li>
            <li class="list">
              <a href="../user/users.php" class="nav-link">
                <i class='bx bx-user icon'></i>
                <span class="link">Users</span>
              </a>
            </li>
            <li class="list">
              <a href="../agent/agents.php" class="nav-link">
                <i class='bx bx-user-pin icon'></i>
                <span class="link">Agent</span>
              </a>
            </li>
            <li class="list">
              <a href="../subscribtion/subscribtion.php" class="nav-link">
                <i class='bx bx-id-card icon'></i>
                <span class="link">Abonnement</span>
              </a>
            </li>
            <li class="list">
                <a href="../declaration/declaration.php" class="nav-link">
                  <i class='bx bxs-bell-ring'></i>
                  <span class="link">Declaration de parte</span>
                </a>
            </li>
          </ul>
          <div class="bottom-cotent">
            <li class="list">
              <a href="../profile/index.php" class="nav-link">
                <i class='bx bx-user-circle icon'></i>
                <span class="link">Profile</span>
              </a>
            </li>
            <li class="list">
              <a href="../deconnection.php" class="nav-link">
                <i class="bx bx-log-out icon"></i>
                <span class="link">deconnection</span>
              </a>
            </li>
          </div>
        </div>
      </div>
    </nav>
    <section class="overlay"></section>
      <main class="table" id="customers_table">
          <section class="table__header">
              <h1>Table d'abonemment</h1>
          </section>
          <section class="table__body">
              <table>
                  <thead>
                  
                      <tr>
                          <th> Id <span class="icon-arrow"></span></th>
                          <th> Client <span class="icon-arrow"></span></th>
                          <th> Order Date <span class="icon-arrow"></span></th>
                          <th> Status <span class="icon-arrow"></span></th>
                          <th> Plan <span class="icon-arrow"></span></th>  
                          <th> Modifier <span class="icon-arrow"></span></th>
                      </tr>
                  </thead>
                  <tbody>
                  <?php foreach ($users as $user) :
                    
                    $clientStmt = $c->prepare("SELECT Nom, Prenom FROM users WHERE clientID = :clientID");
            $clientStmt->bindParam(':clientID', $user['clientID'], PDO::PARAM_INT);
            $clientStmt->execute();

            // Check if the query execution was successful before accessing the array offset
            $clientInfo = $clientStmt->fetch(PDO::FETCH_ASSOC);
            if ($clientInfo) {
                    ?>
                      <tr>
                          <td> <?php echo $user['ID']; ?></td>
                          <td> <?php echo $clientInfo['Nom']. ' ' . $clientInfo['Prenom']; ?></td>
                          <td> <?php echo $user['Orderdate']; ?> </td>
                          <td>
                          <?php   if($user['Status']=='Activer' || $user['Status']=='activer') { ?>
                              <p class="status delivered"><?php echo $user['Status']; ?></p>
                              <?php  }  ?>

                              <?php   if($user['Status']=='Deactiver' || $user['Status']=='deactiver') { ?>
                              <p class="status cancelled"><?php echo $user['Status']; ?></p>
                              <?php  }  ?>

                              <?php   if($user['Status']=='En attente' ||  $user['Status']=='en_attente') { ?>
                              <p class="status pending"><?php echo $user['Status']; ?></p>
                              <?php  }  ?>
                              
                          </td>
                          <td> <strong><?php echo $user['Plan']; ?></strong></td>
                          <td>
                          <button class="status shipped" data-userid="<?php echo $user['ID']; ?>" onclick="showStatusOptions(this)">Modifier</button>
                          </td>
                      </tr>
                      <?php }endforeach; ?>
                  </tbody>
              </table>
          </section>
      </main>
      <script src="subscribtion.js"></script>
       <script src="../index.js"></script>
    </section>

</body>

</html>
