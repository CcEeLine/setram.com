<?php
session_start();
require_once '../../datebase/Database.php';

$Db = new Database("projet");

try {
    $Db->connexion_to_server();
    $Db->create_db();
    $c = $Db->connect_to_db();
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {
    $id = $_POST['id_to_modify']; 
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $date = $_POST['date'];
    $genre = $_POST['genre'];
    $email = $_POST['email'];

    

    // Build the SQL update query based on the filled fields
    $updateFields = [];
    $params = [];

    if (!empty($nom)) {
        $updateFields[] = "nom = ?";
        $params[] = $nom;
    }

    if (!empty($prenom)) {
        $updateFields[] = "prenom = ?";
        $params[] = $prenom;
    }

    if (!empty($date)) {
        $updateFields[] = "datedenaissance = ?";
        $params[] = $date;
    }

    if (!empty($genre)) {
        $updateFields[] = "genre = ?";
        $params[] = $genre;
    }

    if (!empty($email)) {
        $updateFields[] = "email = ?";
        $params[] = $email;
    }

    // Perform the update if at least one field is filled
    if (!empty($updateFields)) {
        $updateFieldsStr = implode(", ", $updateFields);
        $stmt = $c->prepare("UPDATE agent SET $updateFieldsStr WHERE agentid = ?");
        $params[] = $id;
        $stmt->execute($params);
    }

    // Redirect to the user list page after successful update
    header("Location: agents.php");
    exit();
} else {
    // Handle case where the request method is not POST or 'update' is not set
    die("Invalid request");
}
?>
