<?php
session_start();
require_once '../../datebase/Database.php';

$Db = new Database("projet");

try {
    $Db->connexion_to_server();
    $Db->create_db();
    $c = $Db->connect_to_db();
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
  // Admin is not logged in, redirect to the login page or show an error message
  header("Location: ../connect/connect.php"); // Change 'login.php' to your actual login page
  exit();
}
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $id_to_modify = $_GET['id'];

    $stmt = $c->prepare("SELECT * FROM agent WHERE agentid = ?");
    $stmt->execute([$id_to_modify]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        // Handle case where user with specified ID is not found
        die("User not found");
    }
}


?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Agent </title> 
    <link rel="stylesheet" href="add.css">
   </head>

<body>
  <div class="wrapper">
    <h2>Update Agent</h2>
    <form action="updateAgent.php" method="post">

      <div class="input-box">
        <input for="nom"  type="text" name="nom" placeholder="Nom" required value="<?php echo $user['nom']; ?>">
      </div>
      <div class="input-box">
        <input for="prenom"  type="text" name="prenom" placeholder="Prenom" required value="<?php echo $user['prenom']; ?>">
      </div>
      <div class="input-box">
        <input for="date" type="date" name="date" placeholder="Date de naissance" required
                   value="<?php echo $user['datedenaissance']; ?>">
      </div>
      <div class="input-box">
        <input type="radio" id="homme" name="genre" value="homme" <?php echo ($user['genre'] === 'homme') ? 'checked' : ''; ?> required>
        <label for="homme">homme</label>
        <input type="radio" id="femme" name="genre" value="femme"  <?php echo ($user['genre'] === 'femme') ? 'checked' : ''; ?> required>
        <label for="femme">femme</label>
      </div>
      <div class="input-box">
        <input for="email" type="email" name="email" placeholder="Email" required value="<?php echo $user['email']; ?>">
      </div>
     
      <div class="input-box button">
      <input type="hidden" name="id_to_modify" value="<?php echo $id_to_modify; ?>">
        <input type="Submit" name="update" value="mise a jour">
      </div>
    </form>
    <a href="agents.php" class="btn btn-danger">Revenir a la page precedante</a>
  </div>
</body>
</html>
             








 

